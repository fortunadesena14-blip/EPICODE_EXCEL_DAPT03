# CASE STUDY
# TASK 2: creazione databases e tabelle
CREATE DATABASE ToysGroup;
USE ToysGroup;

CREATE TABLE Category (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    NomeCategoria VARCHAR(50) NOT NULL
);

CREATE TABLE Product (
    ProductID VARCHAR(10) PRIMARY KEY,
    NomeProdotto VARCHAR(50),
    ListPrice DECIMAL(10,2),   -- prezzo di listino
    Status VARCHAR(50),
    Colore VARCHAR(50),
    CategoryID INT NOT NULL,
    FOREIGN KEY(CategoryID) REFERENCES Category(CategoryID)
);

CREATE TABLE Region (
    RegioneID INT PRIMARY KEY,
    NomeRegione VARCHAR(50) NOT NULL
);

CREATE TABLE Country (
    CountryID INT PRIMARY KEY,
    NomeCitta VARCHAR(50) NOT NULL,
    RegioneID INT NOT NULL,
    FOREIGN KEY (RegioneID) REFERENCES Region(RegioneID)
);

CREATE TABLE Sales (
    SaleID VARCHAR(20) PRIMARY KEY,
    ProductID VARCHAR(10) NOT NULL,
    CountryID INT NOT NULL,
    OrderDate DATE,
    Quantita INT NOT NULL,
    UnitPrice DECIMAL(10,2),                -- prezzo unitario reale della vendita
    TotaleVendite DECIMAL(10,2) AS (Quantita * UnitPrice),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (CountryID) REFERENCES Country(CountryID)
);

# TASK 3: alimentazione tabelle
INSERT INTO Category (NomeCategoria) 
VALUES
('Bikes'),
('Clothing'),
('Toys'),
('Accessories'),
('Electronics');

INSERT INTO Product (ProductID, NomeProdotto, ListPrice, Status, Colore, CategoryID) 
VALUES
('B100','Bikes-100',140.00, 'Disponibile','Rosso',1),
('B200','Bikes-200',190.00,'Non Disponibile','Blu',1),
('BH001','Bike-Helmet-S',22.00,'Disponibile','Nero',4),
('BH002','Bike-Helmet-M',28.00,'Disponibile','Rosso',4),
('BG01','Bike-Glove-M',13.00,'Non Disponibile','Nero',2),
('BG02','Bike-Glove-L',15.00,'Disponibile','Blu',2),
('DOLL01','Doll-Barbie',18.00,'Disponibile','Rosa',3),
('LEGO500','Lego-Set-500',45.00,'Non Disponibile','Multicolore',3), 
('RCB01','RC-Car-Basic',75.00,'Non Disponibile','Rosso',5),          
('RCP01','RC-Car-Pro',110.00,'Disponibile','Blu',5);                  

INSERT INTO Region (RegioneID, NomeRegione) 
VALUES
(1,'EstEuropa'),
(2,'SudEuropa'),
(3,'NordAmerica'),
(4,'AsiaPacifico');

INSERT INTO Country (CountryID, NomeCitta, RegioneID) 
VALUES
(1,'Francia',1),
(2,'Germania',1),
(3,'Italia',2),
(4,'Grecia',2),
(5,'USA',3),
(6,'Canada',3),
(7,'Giappone',4),
(8,'Australia',4);

INSERT INTO Sales (SaleID, ProductID, CountryID, OrderDate, Quantita, UnitPrice) 
VALUES
('S001','B100',1,'2023-05-01',10,150.00),
('S002','B200',2,'2023-05-02',5,200.00),
('S003','BH001',1,'2023-05-03',20,25.00),
('S004','BH002',3,'2023-05-04',15,30.00),
('S005','BG01',3,'2023-05-05',25,15.00),
('S006','BG02',4,'2023-05-06',30,17.00),
('S007','DOLL01',3,'2023-05-07',12,20.00);
select * from category;
select * from product;
select * from region;
select * from country;
select * from sales;

# Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a:
-- 1)	Verificare che i campi definiti come PK siano univoci. 
-- In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).
-- 2 metodi 
SELECT CategoryID
FROM category
WHERE CategoryID is NULL;

SELECT CategoryID,
Count(*)
FROM category
GROUP BY CategoryID
HAVING Count(*) > 1;
--
SELECT ProductID
FROM Product
WHERE ProductID IS NULL;

SELECT ProductID,
Count(*)
FROM product
GROUP BY ProductID
HAVING Count(*) > 1;
--
SELECT CountryID
FROM Country
WHERE CountryID IS NULL;

SELECT CountryID,
Count(*)
FROM country
GROUP BY CountryID
HAVING Count(*) > 1;
--
SELECT RegioneID
FROM Region
WHERE RegioneID IS NULL;

SELECT RegioneID,
Count(*)
FROM region
GROUP BY RegioneID
HAVING Count(*) > 1;

--
SELECT SaleID
FROM Sales
WHERE SaleID IS NULL;

SELECT SaleID,
Count(*)
FROM sales
GROUP BY SaleID
HAVING Count(*) > 1;
--
# l'univocità viene verificata dal momento in cui come risultato del group by non abbiamo nulla: nessuna PK è nulla e duplicata.
##################################################################################################################################################
-- 2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
-- il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT 
    S.SaleID as CodiceVendita,
    S.OrderDate as DataOrdine,
    P.NomeProdotto as NomeProdotto,
    Ca.NomeCategoria as Categoria,
    Co.NomeCitta as Stato,
    R.NomeRegione as RegioneVendita,
    IF(DATEDIFF( '2025-10-31', S.OrderDate) > 180, 'True', 'False') AS Oltre180Giorni
FROM Sales as S
JOIN Product as P
ON S.ProductID = P.ProductID
JOIN Category as Ca
ON P.CategoryID = Ca.CategoryID
JOIN Country as Co
ON S.CountryID = Co.CountryID
JOIN Region as R
ON Co.RegioneID = R.RegioneID;

-- 3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
# (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
-- Nel result set devono comparire solo il codice prodotto e il totale venduto.

SELECT 
ProductID, 
SUM(TotaleVendite) AS Fatturato 
FROM Sales 
WHERE YEAR(OrderDate) = (SELECT MAX(YEAR(OrderDate)) FROM Sales) 
GROUP BY ProductID 
HAVING SUM(Quantita) > ( 
SELECT AVG(Quantita) 
FROM Sales);

-- 4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
SELECT
    S.ProductID AS CodiceProdotto,
    P.NomeProdotto AS Prodotto,
    YEAR(S.OrderDate) AS Anno,
    SUM(S.TotaleVendite) AS Fatturato
FROM Sales AS S
JOIN Product AS P
    ON S.ProductID = P.ProductID
GROUP BY S.ProductID, P.NomeProdotto, YEAR(S.OrderDate);

-- elenco solo con i nomi prodotti e non i codici
SELECT
    P.NomeProdotto AS Prodotto,
    YEAR(S.OrderDate) AS Anno,
    SUM(S.TotaleVendite) AS Fatturato
FROM Sales AS S
JOIN Product AS P
    ON S.ProductID = P.ProductID
GROUP BY  P.NomeProdotto, YEAR(S.OrderDate);

-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
Select
SUM(S.TotaleVendite) as Fatturato,
YEAR(S.OrderDate) as Anno,
Co.NomeCitta as Stato
FROM Sales as S
JOIN Country as Co
ON S.CountryID = Co.CountryID
GROUP BY Co.NomeCitta, Year(OrderDate)
ORDER BY YEAR(OrderDate), Fatturato DESC;

-- 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT 
Ca.NomeCategoria as Categoria,
SUM(S.Quantita) as TotQuantita
FROM Sales AS S
JOIN Product p 
ON S.ProductID = P.ProductID
JOIN Category as Ca 
ON P.CategoryID = Ca.CategoryID
GROUP BY Ca.NomeCategoria
ORDER BY TotQuantita DESC;

-- Clothing è la più richiesta

-- 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- 1. effettuare una left join tra sales e product
SELECT
P.ProductID as CodiceProdotto,
P.NomeProdotto as Nome,
S.SaleID as CodiceVendite
FROM Product as P
LEFT JOIN Sales as S
ON S.ProductID = P.ProductID
WHERE S.SaleID is null;
-- prodotti invenduti sono Lego-Set-500; RC-Car-Basic,RC-Car-Pro.

-- 2. usare NOT IN
SELECT 
P.ProductID as CodiceProdotto, 
P.NomeProdotto as Nome
FROM Product as P
WHERE P.ProductID NOT IN (
    SELECT DISTINCT S.ProductID
    FROM Sales as S
);

-- 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
-- (codice prodotto, nome prodotto, nome categoria)
CREATE VIEW REPORT_PRODOTTI AS
SELECT 
P.ProductID as CodiceProdotto,
P.NomeProdotto as Nome,
Ca.NomeCategoria as Categoria
FROM Product as P
JOIN Category as Ca
ON P.CategoryID = Ca.CategoryID;
select * from REPORT_PRODOTTI;

-- 9)	Creare una vista per le informazioni geografiche
CREATE VIEW INFO_GEOGRAFICHE AS
SELECT 
S.SaleID AS CodiceVendita,
S.OrderDate AS DataOrdine,
Co.NomeCitta AS Stato,
R.NomeRegione AS Regione,
P.ProductID AS CodiceProdotto,
P.NomeProdotto AS NomeProdotto
FROM Sales as S
JOIN Product as P
ON S.ProductID = P.ProductID
JOIN Country as Co
ON S.CountryID = Co.CountryID
JOIN Region as R
ON Co.RegioneID = R.RegioneID;
select * from INFO_GEOGRAFICHE;


